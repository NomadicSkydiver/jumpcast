# JumpCast Android App

This Android project packages the live JumpCast website as an installable Android application.

- App name: JumpCast
- Package: `com.nomadicskydiver.jumpcast`
- Website: https://jumpcast.onrender.com
- Minimum Android version: Android 6.0 (API 23)
- The app uses the live website, so website updates are reflected in the app without rebuilding the APK.

## Build

The included GitHub Actions workflow builds a debug APK and uploads it as an artifact.
